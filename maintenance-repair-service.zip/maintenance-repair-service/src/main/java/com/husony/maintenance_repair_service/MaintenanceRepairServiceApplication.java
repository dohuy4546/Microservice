package com.husony.maintenance_repair_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaintenanceRepairServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaintenanceRepairServiceApplication.class, args);
	}

}
