package com.husony.device_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeviceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
